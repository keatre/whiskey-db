# Whiskey DB (Self-Hosted Collection + Valuations)

Quick start:

```bash
cp .env.example .env
docker compose up --build
```
- Web UI: http://localhost:8080
- API: http://localhost:8000/docs
