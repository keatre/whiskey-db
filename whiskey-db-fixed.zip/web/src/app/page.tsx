export default function Home() {
  return (
    <main>
      <h1>Whiskey DB</h1>
      <p>Welcome. Use the Bottles page to browse and add entries.</p>
      <a href="/bottles">Go to Bottles →</a>
    </main>
  );
}
